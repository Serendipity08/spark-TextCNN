package com.musicwise.model;

public enum GiftStatus {
    CREATED,
    OPENED,
    COMPLETED,
    LIKED
}
